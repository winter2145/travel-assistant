package com.xin.aiagentbackend.config;

import com.xin.aiagentbackend.tools.AttractionSearchTool;
import com.xin.aiagentbackend.tools.BudgetCalculatorTool;
import com.xin.aiagentbackend.tools.BudgetCheckTool;
import com.xin.aiagentbackend.tools.ConflictCheckTool;
import com.xin.aiagentbackend.tools.FoodCuisineSearchTool;
import com.xin.aiagentbackend.tools.ItineraryAdjustTool;
import com.xin.aiagentbackend.tools.ItineraryGenerateTool;
import com.xin.aiagentbackend.tools.MapRouteTool;
import com.xin.aiagentbackend.tools.WeatherSearchTool;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 工具装配配置：
 * 把 tools 包下 9 个 @Tool 工具收集为 ToolCallbackProvider，
 * 并导出 ToolCallback[] allTools Bean，供 LoveApp.doChatWithTools 注册给 LLM。
 */
@Configuration
public class ToolConfig {

    @Bean
    public ToolCallbackProvider travelToolCallbackProvider(
            AttractionSearchTool attractionSearchTool,
            FoodCuisineSearchTool foodCuisineSearchTool,
            WeatherSearchTool weatherSearchTool,
            MapRouteTool mapRouteTool,
            BudgetCalculatorTool budgetCalculatorTool,
            BudgetCheckTool budgetCheckTool,
            ConflictCheckTool conflictCheckTool,
            ItineraryGenerateTool itineraryGenerateTool,
            ItineraryAdjustTool itineraryAdjustTool) {

        return MethodToolCallbackProvider.builder()
                .toolObjects(
                        attractionSearchTool,
                        foodCuisineSearchTool,
                        weatherSearchTool,
                        mapRouteTool,
                        budgetCalculatorTool,
                        budgetCheckTool,
                        conflictCheckTool,
                        itineraryGenerateTool,
                        itineraryAdjustTool
                )
                .build();
    }

    @Bean
    public ToolCallback[] allTools(ToolCallbackProvider travelToolCallbackProvider) {
        return travelToolCallbackProvider.getToolCallbacks();
    }
}
