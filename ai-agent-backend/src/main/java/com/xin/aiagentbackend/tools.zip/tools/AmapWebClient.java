package com.xin.aiagentbackend.tools;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.xin.aiagentbackend.tools.common.AmapApiException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 高德开放平台 Web 服务客户端。
 *
 * <p>统一封装：Key 管理、连接/读取超时、请求日志（Key 脱敏）、
 * 高德业务状态校验（status=0 视为失败）与异常转换。
 * 业务失败统一抛 {@link AmapApiException}，由调用方工具转成 {@link com.xin.aiagentbackend.tools.common.ToolResult}。
 */
@Slf4j
@Component
public class AmapWebClient {

    /** 高德 Web 服务基础地址 */
    private static final String AMAP_BASE_URL = "https://restapi.amap.com";
    /** 连接超时（毫秒） */
    private static final int CONNECT_TIMEOUT_MS = 5_000;
    /** 读取超时（毫秒） */
    private static final int READ_TIMEOUT_MS = 10_000;

    private final RestClient client;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final String key;

    /** 高德接口被调用的总次数（供集成测试验证） */
    private final AtomicLong requestCount = new AtomicLong();

    public AmapWebClient(@Value("${amap.web.key:}") String key) {
        this.key = key == null ? "" : key.trim();
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(CONNECT_TIMEOUT_MS);
        requestFactory.setReadTimeout(READ_TIMEOUT_MS);
        this.client = RestClient.builder()
                .baseUrl(AMAP_BASE_URL)
                .requestFactory(requestFactory)
                .build();
    }

    /**
     * 请求高德 Web 服务接口。
     *
     * @param path   接口路径，如 /v3/place/text
     * @param params 业务查询参数（非空值才会拼入 URL）
     * @return 高德返回的 JSON 字符串
     * @throws AmapApiException Key 未配置、网络异常或高德业务失败
     */
    public String get(String path, Map<String, ?> params) {
        long seq = requestCount.incrementAndGet();
        long start = System.currentTimeMillis();
        if (key.isBlank()) {
            throw new AmapApiException("未配置高德 Web 服务 Key，请配置 amap.web.key 或环境变量 AMAP_WEB_KEY");
        }
        try {
            String body = client.get()
                    .uri(builder -> {
                        builder.path(path).queryParam("key", key);
                        params.forEach((k, v) -> {
                            if (v != null && !v.toString().isBlank()) {
                                builder.queryParam(k, v);
                            }
                        });
                        return builder.build();
                    })
                    .retrieve()
                    .body(String.class);
            assertAmapSuccess(body);
            log.info("[amap#{}] GET {} success in {}ms, respLen={}",
                    seq, path, System.currentTimeMillis() - start, body == null ? 0 : body.length());
            return body;
        } catch (AmapApiException e) {
            log.warn("[amap#{}] GET {} business error in {}ms: {}",
                    seq, path, System.currentTimeMillis() - start, e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("[amap#{}] GET {} failed in {}ms", seq, path, System.currentTimeMillis() - start, e);
            throw new AmapApiException("高德接口调用异常：" + e.getMessage(), e);
        }
    }

    /**
     * 高德接口被调用的总次数。
     *
     * @return 累计请求次数
     */
    public long getRequestCount() {
        return requestCount.get();
    }

    /**
     * 校验高德响应：status=1 视为成功；status=0 视为业务失败并抛出异常。
     *
     * @param body 高德响应体（可能为空或非 JSON）
     */
    private void assertAmapSuccess(String body) {
        if (body == null || body.isBlank()) {
            throw new AmapApiException("高德接口返回空响应");
        }
        try {
            JsonNode root = objectMapper.readTree(body);
            if ("0".equals(root.path("status").asText(""))) {
                String infocode = root.path("infocode").asText("");
                String info = root.path("info").asText("未知错误");
                throw new AmapApiException("高德接口返回失败：infocode=" + infocode + ", info=" + info);
            }
        } catch (AmapApiException e) {
            throw e;
        } catch (Exception ignored) {
            // 非 JSON 响应不做业务校验，原样透传
        }
    }
}
